package AbstractFactory;

public class Ecommerce extends Channel{
	//private String channelType;

	public String toString()
	{
		return "Channel Type :: E-commerce Website";
	}
}
